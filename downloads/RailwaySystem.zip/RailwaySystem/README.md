Our project is an implementation of the railway management system.

First, the user is asked to login or register. Already registered users can log in.

Then, the user is given option to see the current bookings, or to add or delete his current bookings.

The user can see also see the ticket for a particular booking, on choosing the opotion to see the current bookings.

A list of all the functions can be seen in the file - functions.h. A Makefile has been used to compile all the different files. The main code is in the file - main.c. It can be run using the command : ./railway_system.

A detailed description of each module can be found in the file "Railway System Implementation.docx".
We have used 7 train files, which contain the schedule of those trains.
